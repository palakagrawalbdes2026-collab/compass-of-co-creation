# Five Whys Prompt Template — Chrome Extension

A Chrome extension that injects a structured **Five Whys** prompt template into
ChatGPT, Gemini, Claude, and DeepSeek chat interfaces.

## Installation (Developer Mode)

1. **Unzip / place** this folder somewhere permanent on your computer (don't move it after installing).

2. Open Chrome and navigate to:  
   `chrome://extensions`

3. Enable **Developer mode** (toggle in the top-right corner).

4. Click **"Load unpacked"**.

5. Select the `five-whys-extension` folder.

6. The extension icon (purple ×5) appears in your toolbar. Pin it for easy access.

## How to Use

### On a supported AI chat page (ChatGPT / Gemini / Claude / DeepSeek):

- A **"5 Whys"** button appears in the bottom-right corner of the page.
- Click it to open the template picker.
- Select **Default Five Whys** — the template is instantly inserted into the chat input.
- Press **Tab** to jump between `[bracket placeholders]` and fill them in.
- Submit to the AI as normal.

### From the popup (toolbar icon):

- Click the extension icon in Chrome's toolbar.
- **Quick Insert tab**: one-click insert the default template into the active AI tab.
- **Templates tab**: save brand-specific or project-specific template variants (e.g., "Kotak Campaign", "Mederma Launch").
- **History tab**: see and re-insert your 10 most recent templates.

## Supported Platforms

| Platform   | URL                          |
|------------|------------------------------|
| ChatGPT    | chat.openai.com / chatgpt.com|
| Gemini     | gemini.google.com            |
| Claude     | claude.ai                    |
| DeepSeek   | chat.deepseek.com            |

## Default Template

```
I need [specific output — e.g., a tagline, a headline, a campaign concept].

Because [Why #1 — immediate reason: what is the direct need?].
Because [Why #2 — slightly deeper: what goal does this serve?].
Because [Why #3 — strategic layer: what business objective is this tied to?].
Because [Why #4 — emotional or brand layer: what feeling or identity should this convey?].
Because [Why #5 — ultimate purpose: what is the deepest "why" behind all of this?].

Now generate [specific output] that reflects all five layers above.
```

## File Structure

```
five-whys-extension/
├── manifest.json       ← Chrome extension manifest (MV3)
├── content.js          ← Injected into AI chat pages
├── styles.css          ← Button & UI styles (auto dark/light mode)
├── popup.html          ← Settings popup
├── popup.js            ← Popup logic
└── icons/
    ├── icon16.svg
    ├── icon48.svg
    └── icon128.svg
```

## Troubleshooting

- **Button not appearing?** Reload the AI chat page after installing.
- **Template not inserting?** Click inside the chat input box first, then click the 5 Whys button.
- **ChatGPT updated its UI?** Open a GitHub issue — input selectors may need updating.

## Privacy

No data is sent anywhere. All saved templates and history are stored locally in
Chrome's `storage.local` (your browser only).
