/**
 * Five Whys Prompt Template - Content Script
 * Injects a "5 Whys" button near the chat input on supported AI platforms.
 * Supported: ChatGPT, Gemini, Claude, DeepSeek
 */

(function () {
  "use strict";

  // ─── Platform detection ────────────────────────────────────────────────────
  const PLATFORMS = {
    chatgpt: {
      name: "ChatGPT",
      hostMatch: /chat\.openai\.com|chatgpt\.com/,
      inputSelectors: [
        "#prompt-textarea",
        "textarea[data-id='root']",
        "textarea[placeholder]",
        "[contenteditable='true'][data-virtualkeyboard]",
        "div[contenteditable='true'].ProseMirror"
      ],
      toolbarSelectors: [
        "div[class*='composer-footer']",
        "div[class*='chat-input']",
        "form > div:last-child",
        "[data-testid='send-button']"
      ],
      anchorSelector: "[data-testid='send-button'], button[aria-label='Send prompt']",
      theme: "dark"
    },
    gemini: {
      name: "Gemini",
      hostMatch: /gemini\.google\.com/,
      inputSelectors: [
        "rich-textarea .ql-editor",
        "div[contenteditable='true']",
        "textarea"
      ],
      anchorSelector: "button[aria-label='Send message'], .send-button",
      theme: "light"
    },
    claude: {
      name: "Claude",
      hostMatch: /claude\.ai/,
      inputSelectors: [
        "div[contenteditable='true'].ProseMirror",
        "[contenteditable='true']",
        "textarea"
      ],
      anchorSelector: "button[aria-label='Send Message'], button[type='submit']",
      theme: "light"
    },
    deepseek: {
      name: "DeepSeek",
      hostMatch: /chat\.deepseek\.com/,
      inputSelectors: [
        "textarea#chat-input",
        "textarea",
        "[contenteditable='true']"
      ],
      anchorSelector: "button[aria-label='send'], div[role='button'][class*='send']",
      theme: "dark"
    }
  };

  // ─── Template definition ───────────────────────────────────────────────────
  const DEFAULT_TEMPLATE = `I need [specific output — e.g., a tagline, a headline, a campaign concept].

Because [Why #1 — immediate reason: what is the direct need?].
Because [Why #2 — slightly deeper: what goal does this serve?].
Because [Why #3 — strategic layer: what business objective is this tied to?].
Because [Why #4 — emotional or brand layer: what feeling or identity should this convey?].
Because [Why #5 — ultimate purpose: what is the deepest "why" behind all of this?].

Now generate [specific output] that reflects all five layers above.`;

  const BRACKET_REGEX = /\[[^\]]+\]/g;

  // ─── State ─────────────────────────────────────────────────────────────────
  let currentPlatform = null;
  let injectedButton = null;
  let observerRetries = 0;
  const MAX_RETRIES = 30;

  // ─── Detect current platform ───────────────────────────────────────────────
  function detectPlatform() {
    const host = window.location.hostname;
    for (const [key, cfg] of Object.entries(PLATFORMS)) {
      if (cfg.hostMatch.test(host)) return { key, ...cfg };
    }
    return null;
  }

  // ─── Find chat input element ───────────────────────────────────────────────
  function findInput(platform) {
    for (const sel of platform.inputSelectors) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    return null;
  }

  // ─── Insert template into the chat box ────────────────────────────────────
  function insertTemplate(platform, customTemplate) {
    const template = customTemplate || DEFAULT_TEMPLATE;
    const input = findInput(platform);
    if (!input) {
      showToast("Could not find the chat input. Please click the text box first.");
      return;
    }

    input.focus();

    if (input.tagName === "TEXTAREA" || input.tagName === "INPUT") {
      // Native textarea
      const start = input.selectionStart || 0;
      const before = input.value.slice(0, start);
      const after = input.value.slice(input.selectionEnd || start);
      input.value = before + (before ? "\n\n" : "") + template + after;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));

      // Move cursor to first bracket
      const firstBracket = input.value.indexOf("[");
      if (firstBracket !== -1) {
        const closeBracket = input.value.indexOf("]", firstBracket);
        input.setSelectionRange(firstBracket, closeBracket + 1);
      }

    } else if (input.getAttribute("contenteditable") === "true") {
      // ContentEditable / ProseMirror (Claude, Gemini, newer ChatGPT)
      insertIntoContentEditable(input, template, platform);
    }

    // Add tab-cycling behaviour
    addBracketTabbing(input, platform);

    input.focus();
  }

  // ─── Insert into contenteditable ──────────────────────────────────────────
  function insertIntoContentEditable(el, template, platform) {
    el.focus();

    // Try execCommand first (widely supported)
    const prefix = el.innerText.trim() ? "\n\n" : "";

    // For ProseMirror (Claude/ChatGPT), we need to dispatch proper events
    try {
      // Select all existing text to check if we should prefix
      const sel = window.getSelection();

      // Move to end
      sel.selectAllChildren(el);
      sel.collapseToEnd();

      const fullText = prefix + template;

      // Use clipboard approach for ProseMirror
      const success = document.execCommand("insertText", false, fullText);
      if (!success) {
        // Fallback: directly set innerHTML (may lose formatting)
        el.innerText = (el.innerText.trim() ? el.innerText + "\n\n" : "") + template;
        el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: fullText }));
      }
    } catch (e) {
      el.innerText = template;
      el.dispatchEvent(new InputEvent("input", { bubbles: true }));
    }
  }

  // ─── Tab cycling between brackets ─────────────────────────────────────────
  function addBracketTabbing(input, platform) {
    // Remove existing listener first
    if (input._fiveWhysTabHandler) {
      input.removeEventListener("keydown", input._fiveWhysTabHandler);
    }

    const handler = function (e) {
      if (e.key !== "Tab") return;
      e.preventDefault();

      const text = input.tagName === "TEXTAREA" ? input.value : input.innerText;
      const matches = [...text.matchAll(BRACKET_REGEX)];
      if (!matches.length) return;

      if (input.tagName === "TEXTAREA") {
        const cursorPos = input.selectionStart;
        // Find the next bracket after cursor
        let target = null;
        for (const m of matches) {
          if (m.index > cursorPos - 1) { target = m; break; }
        }
        // Wrap around
        if (!target) target = matches[0];
        input.setSelectionRange(target.index, target.index + target[0].length);
      } else {
        // contenteditable: use Selection API
        cycleContenteditableBrackets(input, e.shiftKey);
      }
    };

    input._fiveWhysTabHandler = handler;
    input.addEventListener("keydown", handler);
  }

  function cycleContenteditableBrackets(el, reverse) {
    const text = el.innerText;
    const matches = [...text.matchAll(BRACKET_REGEX)];
    if (!matches.length) return;

    const sel = window.getSelection();
    if (!sel.rangeCount) return;

    // Get approximate cursor offset in plain text
    const range = sel.getRangeAt(0);
    const preRange = document.createRange();
    preRange.selectNodeContents(el);
    preRange.setEnd(range.startContainer, range.startOffset);
    const cursorOffset = preRange.toString().length;

    let target = null;
    if (!reverse) {
      for (const m of matches) {
        if (m.index > cursorOffset) { target = m; break; }
      }
      if (!target) target = matches[0];
    } else {
      for (let i = matches.length - 1; i >= 0; i--) {
        if (matches[i].index < cursorOffset - 1) { target = matches[i]; break; }
      }
      if (!target) target = matches[matches.length - 1];
    }

    // Walk text nodes to find and select the bracket
    selectTextInContentEditable(el, target.index, target.index + target[0].length);
  }

  function selectTextInContentEditable(el, start, end) {
    const nodes = [];
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) nodes.push(node);

    let offset = 0;
    let startNode = null, startOff = 0, endNode = null, endOff = 0;

    for (const n of nodes) {
      const len = n.textContent.length;
      if (!startNode && offset + len > start) {
        startNode = n;
        startOff = start - offset;
      }
      if (!endNode && offset + len >= end) {
        endNode = n;
        endOff = end - offset;
        break;
      }
      offset += len;
    }

    if (startNode && endNode) {
      const range = document.createRange();
      range.setStart(startNode, startOff);
      range.setEnd(endNode, endOff);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
    }
  }

  // ─── Toast notification ────────────────────────────────────────────────────
  function showToast(msg) {
    let toast = document.getElementById("fw-toast");
    if (!toast) {
      toast = document.createElement("div");
      toast.id = "fw-toast";
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.classList.add("fw-toast-show");
    setTimeout(() => toast.classList.remove("fw-toast-show"), 3000);
  }

  // ─── Load saved templates from storage ────────────────────────────────────
  function getSavedTemplates(cb) {
    chrome.storage.local.get(["fwTemplates", "fwActiveTemplate"], cb);
  }

  // ─── Build & inject the floating button ───────────────────────────────────
  function injectButton(platform) {
    if (document.getElementById("fw-btn-wrapper")) return; // already injected

    const wrapper = document.createElement("div");
    wrapper.id = "fw-btn-wrapper";
    wrapper.setAttribute("data-platform", platform.key);

    const btn = document.createElement("button");
    btn.id = "fw-btn";
    btn.title = "Insert Five Whys Prompt Template";
    btn.setAttribute("aria-label", "Insert Five Whys Prompt Template");
    btn.innerHTML = `
      <span class="fw-icon">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="10"/>
          <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
          <line x1="12" y1="17" x2="12.01" y2="17"/>
        </svg>
      </span>
      <span class="fw-label">5 Whys</span>
    `;

    // Dropdown arrow for saved templates
    const arrow = document.createElement("span");
    arrow.className = "fw-arrow";
    arrow.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 6" fill="currentColor"><path d="M0 0l5 6 5-6z"/></svg>`;
    btn.appendChild(arrow);

    // Dropdown menu
    const menu = document.createElement("div");
    menu.id = "fw-menu";
    menu.innerHTML = `
      <div class="fw-menu-header">Templates</div>
      <div class="fw-menu-item fw-default-item" data-template="default">
        <span class="fw-menu-icon">✦</span> Default Five Whys
      </div>
      <div class="fw-menu-divider"></div>
      <div class="fw-saved-list"></div>
      <div class="fw-menu-footer">
        <a href="#" id="fw-open-popup">Manage Templates →</a>
      </div>
    `;

    wrapper.appendChild(btn);
    wrapper.appendChild(menu);
    document.body.appendChild(wrapper);
    injectedButton = wrapper;

    // ── Events ──────────────────────────────────────────────────────────────

    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const isOpen = menu.classList.contains("fw-open");
      if (isOpen) {
        menu.classList.remove("fw-open");
        return;
      }
      refreshMenuItems(menu, platform);
      menu.classList.add("fw-open");
    });

    menu.addEventListener("click", (e) => {
      const item = e.target.closest("[data-template]");
      if (item) {
        e.stopPropagation();
        const key = item.dataset.template;
        if (key === "default") {
          getSavedTemplates(({ fwActiveTemplate }) => {
            insertTemplate(platform, fwActiveTemplate || null);
          });
        } else {
          getSavedTemplates(({ fwTemplates = {} }) => {
            insertTemplate(platform, fwTemplates[key]?.body || null);
          });
        }
        menu.classList.remove("fw-open");
      }
      if (e.target.id === "fw-open-popup") {
        e.preventDefault();
        chrome.runtime.sendMessage({ action: "openPopup" });
        menu.classList.remove("fw-open");
      }
    });

    document.addEventListener("click", () => menu.classList.remove("fw-open"));

    positionButton();
  }

  function refreshMenuItems(menu, platform) {
    getSavedTemplates(({ fwTemplates = {} }) => {
      const list = menu.querySelector(".fw-saved-list");
      list.innerHTML = "";
      const keys = Object.keys(fwTemplates);
      if (keys.length === 0) {
        list.innerHTML = `<div class="fw-menu-empty">No saved templates yet</div>`;
      } else {
        keys.forEach((k) => {
          const d = document.createElement("div");
          d.className = "fw-menu-item";
          d.dataset.template = k;
          d.innerHTML = `<span class="fw-menu-icon">◆</span> ${escapeHtml(fwTemplates[k].name)}`;
          list.appendChild(d);
        });
      }
    });
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  }

  // ─── Position the button in the bottom-right of the viewport ──────────────
  function positionButton() {
    // Button is fixed via CSS; this is a no-op hook for future dynamic placement
  }

  // ─── MutationObserver to wait for page elements ───────────────────────────
  function startObserver(platform) {
    const observer = new MutationObserver(() => {
      const input = findInput(platform);
      if (input && !document.getElementById("fw-btn-wrapper")) {
        injectButton(platform);
      }
    });

    observer.observe(document.body, { childList: true, subtree: true });

    // Initial attempt
    const input = findInput(platform);
    if (input) injectButton(platform);
  }

  // ─── Boot ──────────────────────────────────────────────────────────────────
  function init() {
    currentPlatform = detectPlatform();
    if (!currentPlatform) return;
    startObserver(currentPlatform);
  }

  // Wait a tick for SPAs to finish initial render
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    setTimeout(init, 500);
  }

  // Re-run on SPA navigation
  let lastUrl = location.href;
  new MutationObserver(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      injectedButton = null;
      setTimeout(() => {
        if (currentPlatform && !document.getElementById("fw-btn-wrapper")) {
          injectButton(currentPlatform);
        }
      }, 1000);
    }
  }).observe(document, { subtree: true, childList: true });

  // Listen for messages from popup
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === "insertTemplate") {
      getSavedTemplates(({ fwActiveTemplate }) => {
        insertTemplate(currentPlatform, msg.template || fwActiveTemplate || null);
      });
    }
  });

})();
