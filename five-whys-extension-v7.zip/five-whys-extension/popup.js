// Five Whys — Popup Logic v5

const WHYS = [
  { key: "w1", fallback: "[Why #1 — immediate reason: what is the direct need?]" },
  { key: "w2", fallback: "[Why #2 — slightly deeper: what goal does this serve?]" },
  { key: "w3", fallback: "[Why #3 — strategic layer: what business objective is this tied to?]" },
  { key: "w4", fallback: "[Why #4 — emotional layer: what feeling or identity should this convey?]" },
  { key: "w5", fallback: "[Why #5 — ultimate purpose: what is the deepest \"why\" behind all of this?]" }
];

const ALL_KEYS = ["w0", "w1", "w2", "w3", "w4", "w5"];

function getAnswer(key) {
  const ta = document.querySelector(`textarea[data-key="${key}"]`);
  return ta ? ta.value.trim() : "";
}

function buildPrompt() {
  const what  = getAnswer("w0") || "[specific output]";
  const becauses = WHYS.map(({ key, fallback }) => {
    const val = getAnswer(key);
    return `Because ${val || fallback}.`;
  }).join("\n");

  return `I need ${what}.

${becauses}

Now generate the output above that reflects all five layers.`;
}

// ── Generate: show combined prompt ready to copy ─────────────────
document.getElementById("gen-btn").addEventListener("click", () => {
  const prompt = buildPrompt();
  const box  = document.getElementById("output-box");
  const wrap = document.getElementById("output-wrap");
  box.value = prompt;
  wrap.style.display = "flex";
  box.style.height = "auto";
  box.style.height = box.scrollHeight + "px";
  box.select();
});

// ── Copy button ──────────────────────────────────────────────────
document.getElementById("copy-btn").addEventListener("click", () => {
  const box = document.getElementById("output-box");
  navigator.clipboard.writeText(box.value).then(() => {
    const btn = document.getElementById("copy-btn");
    btn.textContent = "✓ Copied!";
    btn.style.background = "#4ade80";
    btn.style.color = "#0a3020";
    btn.style.borderColor = "#4ade80";
    setTimeout(() => {
      btn.textContent = "Copy";
      btn.style.background = "";
      btn.style.color = "";
      btn.style.borderColor = "";
    }, 2000);
  });
});

// ── Restore saved answers ────────────────────────────────────────
chrome.storage.local.get(["fwAnswers"], ({ fwAnswers = {} }) => {
  ALL_KEYS.forEach(key => {
    const ta = document.querySelector(`textarea[data-key="${key}"]`);
    if (ta && fwAnswers[key]) ta.value = fwAnswers[key];
  });
});

// ── Auto-save on input ───────────────────────────────────────────
ALL_KEYS.forEach(key => {
  const ta = document.querySelector(`textarea[data-key="${key}"]`);
  if (ta) {
    ta.addEventListener("input", () => {
      const fwAnswers = {};
      ALL_KEYS.forEach(k => { fwAnswers[k] = getAnswer(k); });
      chrome.storage.local.set({ fwAnswers });
    });
  }
});

// ── Detect active platform ───────────────────────────────────────
chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
  const url  = tabs[0]?.url || "";
  const dot  = document.getElementById("status-dot");
  const name = document.getElementById("platform-name");
  const map  = [
    [/chat\.openai\.com|chatgpt\.com/, "ChatGPT"],
    [/gemini\.google\.com/,            "Gemini"],
    [/claude\.ai/,                     "Claude"],
    [/chat\.deepseek\.com/,            "DeepSeek"]
  ];
  const match = map.find(([re]) => re.test(url));
  if (match) {
    dot.style.background = "#4ade80";
    name.textContent = "Active on " + match[1];
  } else {
    name.textContent = "No supported AI tab open";
  }
});
