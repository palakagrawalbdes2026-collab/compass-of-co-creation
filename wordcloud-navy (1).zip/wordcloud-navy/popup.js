const SEED_WORDS = [
  'joy', 'trust', 'desire', 'wonder', 'urgency', 'delight', 'nostalgia', 'pride',
  'bold', 'playful', 'sincere', 'warm', 'witty', 'cool', 'rebellious', 'minimal',
  'discover', 'unlock', 'transform', 'ignite', 'create', 'grow', 'connect', 'explore',
  'launch', 'deliver', 'inspire', 'elevate',
  'saves time', 'builds trust', 'drives sales', 'boosts engagement',
  'increases loyalty', 'elevates brand', 'reduces friction',
  'headline', 'tagline', 'CTA', 'body copy', 'manifesto',
  'storytelling', 'authentic', 'disruptive', 'persuasive', 'memorable', 'iconic', 'viral'
];

let words = [];
let selectedWords = new Set();
let idCounter = 0;

function init() {
  chrome.storage.local.get(['words', 'selectedWords', 'idCounter'], (data) => {
    if (data.words && data.words.length > 0) {
      words = data.words;
      idCounter = data.idCounter || words.length;
      selectedWords = new Set(data.selectedWords || []);
      renderAll();
      showCloudLabel();
    } else {
      generateWords();
    }
  });

  document.getElementById('generateBtn').addEventListener('click', generateWords);
  document.getElementById('clearBtn').addEventListener('click', clearAll);
  document.getElementById('addBtn').addEventListener('click', addManualWord);
  document.getElementById('copyBtn').addEventListener('click', copyPrompt);
  document.getElementById('deselectBtn').addEventListener('click', deselectAll);

  document.getElementById('addWordInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') addManualWord();
  });
}

function saveState() {
  chrome.storage.local.set({
    words,
    selectedWords: Array.from(selectedWords),
    idCounter
  });
}

function generateWords() {
  const brief = document.getElementById('briefInput').value.trim();
  const briefWords = brief
    ? brief.split(/[\s,;/\n]+/).map(w => w.trim()).filter(w => w.length > 1)
    : [];

  words = [];
  selectedWords = new Set();
  idCounter = 0;

  const pool = [...new Set([...briefWords, ...SEED_WORDS])];
  const shuffled = pool.sort(() => Math.random() - 0.5).slice(0, 32);
  shuffled.forEach(text => {
    words.push({ id: idCounter++, text });
  });

  renderAll();
  showCloudLabel();
  saveState();
}

function renderAll() {
  const wrap = document.getElementById('cloudsWrap');
  wrap.innerHTML = '';
  words.forEach(w => renderCloud(w, wrap));
  updatePrompt();
}

function renderCloud(wordObj, container) {
  const wrap = container || document.getElementById('cloudsWrap');
  const isSel = selectedWords.has(wordObj.id);
  const div = document.createElement('div');
  div.className = 'cloud-item';
  div.dataset.id = wordObj.id;
  div.innerHTML = `<div class="cloud-pill ${isSel ? 'sel' : 'unsel'}">${escapeHtml(wordObj.text)}</div>`;
  div.addEventListener('click', () => toggleWord(wordObj.id));
  wrap.appendChild(div);
}

function rerenderCloud(id) {
  const el = document.querySelector(`.cloud-item[data-id="${id}"]`);
  if (el) {
    const pill = el.querySelector('.cloud-pill');
    const isSel = selectedWords.has(id);
    pill.className = `cloud-pill ${isSel ? 'sel' : 'unsel'}`;
  }
}

function toggleWord(id) {
  selectedWords.has(id) ? selectedWords.delete(id) : selectedWords.add(id);
  rerenderCloud(id);
  updatePrompt();
  saveState();
}

function deselectAll() {
  const prev = new Set(selectedWords);
  selectedWords.clear();
  prev.forEach(id => rerenderCloud(id));
  updatePrompt();
  saveState();
}

function updatePrompt() {
  const count = selectedWords.size;
  const selBar = document.getElementById('selBar');
  const panel = document.getElementById('promptPanel');
  const selCountEl = document.getElementById('selCount');

  if (count === 0) {
    selBar.style.display = 'none';
    panel.style.display = 'none';
    return;
  }

  selBar.style.display = 'flex';
  selCountEl.textContent = `${count} word${count > 1 ? 's' : ''} selected`;

  const selected = words
    .filter(w => selectedWords.has(w.id))
    .map(w => w.text);

  panel.style.display = 'flex';
  document.getElementById('promptText').textContent =
    `Use these words as creative anchors for your copy:\n\n${selected.join('  ·  ')}\n\nLet each word shape the tone, imagery, or language. Don't use them literally — let them inspire the direction.`;
}

function addManualWord() {
  const inp = document.getElementById('addWordInput');
  const text = inp.value.trim();
  if (!text) return;
  inp.value = '';

  const obj = { id: idCounter++, text };
  words.push(obj);
  renderCloud(obj);
  showCloudLabel();
  saveState();
}

function clearAll() {
  words = [];
  selectedWords = new Set();
  idCounter = 0;
  document.getElementById('cloudsWrap').innerHTML = '';
  document.getElementById('briefInput').value = '';
  document.getElementById('promptPanel').style.display = 'none';
  document.getElementById('selBar').style.display = 'none';
  document.getElementById('cloudLabel').style.display = 'none';
  chrome.storage.local.remove(['words', 'selectedWords', 'idCounter']);
}

function showCloudLabel() {
  const lbl = document.getElementById('cloudLabel');
  if (words.length > 0) lbl.style.display = 'block';
}

function copyPrompt() {
  const text = document.getElementById('promptText').textContent;
  navigator.clipboard.writeText(text).then(() => {
    const status = document.getElementById('copyStatus');
    status.textContent = 'Copied to clipboard!';
    setTimeout(() => { status.textContent = ''; }, 2000);
  });
}

function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

document.addEventListener('DOMContentLoaded', init);
