/* popup.js — Handoff Passport Chrome Extension
   No inline event handlers. All wired via addEventListener. */

const STORAGE_KEY = 'handoff_passports';

let passports = [];
let currentId = null;
let currentStatus = null;
let currentPhase = 0;

const phases = ['Kickoff', 'Strategy', 'Copy', 'Design', 'Review', 'Launch'];

const statusConfig = {
  red:    { label: 'Mostly AI — needs significant human work', pill: 'p-red' },
  yellow: { label: 'Draft complete — needs refinement',       pill: 'p-yellow' },
  green:  { label: 'Ready — approved for next phase',         pill: 'p-green' },
};

/* ─────────────────────────────────────────
   BOOT
───────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', async () => {
  await loadPassports();
  renderHome();
  document.getElementById('f-date').value = new Date().toISOString().split('T')[0];

  // Static button wiring
  document.getElementById('back-btn').addEventListener('click', showHome);
  document.getElementById('delete-btn').addEventListener('click', deletePassport);
  document.getElementById('save-btn').addEventListener('click', savePassport);
  document.getElementById('copy-btn').addEventListener('click', copyPassport);

  // Status pills
  document.querySelectorAll('.pill[data-status]').forEach(pill => {
    pill.addEventListener('click', () => setStatus(pill.dataset.status));
  });

  // Phase nodes
  document.querySelectorAll('.phase-node[data-phase]').forEach(node => {
    node.addEventListener('click', () => setPhase(parseInt(node.dataset.phase, 10)));
  });

  // Live MRZ
  ['f-campaign', 'f-from', 'f-date'].forEach(id => {
    document.getElementById(id).addEventListener('input', updateMRZ);
  });

  // Delegated clicks on passport list (items rendered dynamically)
  document.getElementById('passport-list').addEventListener('click', e => {
    const newBtn = e.target.closest('.new-btn');
    if (newBtn) { newPassport(); return; }

    const item = e.target.closest('.passport-item[data-id]');
    if (item) { editPassport(item.dataset.id); }
  });
});

/* ─────────────────────────────────────────
   STORAGE
───────────────────────────────────────── */
function loadPassports() {
  return new Promise(resolve => {
    chrome.storage.local.get(STORAGE_KEY, data => {
      passports = data[STORAGE_KEY] || [];
      resolve();
    });
  });
}

function saveAll() {
  return new Promise(resolve => {
    chrome.storage.local.set({ [STORAGE_KEY]: passports }, resolve);
  });
}

function genId() {
  return 'HP-' + Date.now().toString().slice(-5);
}

/* ─────────────────────────────────────────
   SCREENS
───────────────────────────────────────── */
function showHome() {
  document.getElementById('screen-home').classList.add('active');
  document.getElementById('screen-form').classList.remove('active');
  renderHome();
}

function showForm() {
  document.getElementById('screen-home').classList.remove('active');
  document.getElementById('screen-form').classList.add('active');
}

/* ─────────────────────────────────────────
   HOME RENDER
───────────────────────────────────────── */
function renderHome() {
  const container = document.getElementById('passport-list');

  const header = `
    <div class="list-header">
      <span class="list-label">Your passports (${passports.length})</span>
      <button class="new-btn">+ New passport</button>
    </div>`;

  if (passports.length === 0) {
    container.innerHTML = header + `
      <div class="empty-state">
        <div class="empty-icon">🛂</div>
        <div class="empty-text">No passports yet.<br>Create one to start tracking your handoffs.</div>
      </div>`;
    return;
  }

  const items = passports
    .slice()
    .sort((a, b) => b.updatedAt - a.updatedAt)
    .map(p => {
      const dotClass = p.status ? `dot-${p.status}` : 'dot-none';
      const phase = p.phase !== undefined ? phases[p.phase] : '';
      const date = p.date ? formatDate(p.date) : '';
      const meta = [phase, date].filter(Boolean).join(' · ');
      return `
        <div class="passport-item" data-id="${escAttr(p.id)}">
          <div class="item-dot ${dotClass}"></div>
          <div class="item-info">
            <div class="item-name">${escHtml(p.campaign || 'Untitled Campaign')}</div>
            <div class="item-meta">${escHtml(meta)}</div>
          </div>
          <div class="item-arrow">›</div>
        </div>`;
    }).join('');

  container.innerHTML = header + items;
}

/* ─────────────────────────────────────────
   CREATE / EDIT / DELETE
───────────────────────────────────────── */
function newPassport() {
  currentId = genId();
  currentStatus = null;
  currentPhase = 0;

  clearForm();
  document.getElementById('f-date').value = new Date().toISOString().split('T')[0];
  document.getElementById('form-topbar-title').textContent = 'New passport';
  document.getElementById('delete-btn').style.display = 'none';

  setStatus(null);
  setPhase(0);
  updateMRZ();
  showForm();
}

function editPassport(id) {
  const p = passports.find(x => x.id === id);
  if (!p) return;

  currentId = id;
  currentStatus = p.status || null;
  currentPhase = p.phase || 0;

  document.getElementById('f-campaign').value = p.campaign || '';
  document.getElementById('f-date').value = p.date || '';
  document.getElementById('f-from').value = p.from || '';
  document.getElementById('f-to').value = p.to || '';
  document.getElementById('f-done').value = p.done || '';
  document.getElementById('f-next').value = p.next || '';
  document.getElementById('f-intent').value = p.intent || '';
  document.getElementById('form-topbar-title').textContent = p.campaign || 'Untitled Campaign';
  document.getElementById('delete-btn').style.display = '';

  setStatus(p.status || null);
  setPhase(p.phase || 0);
  updateMRZ();
  showForm();
}

function savePassport() {
  const passport = buildPassportObj();
  const idx = passports.findIndex(p => p.id === currentId);

  if (idx >= 0) {
    passports[idx] = passport;
  } else {
    passports.push(passport);
  }

  saveAll().then(() => {
    document.getElementById('form-topbar-title').textContent = passport.campaign || 'Untitled Campaign';
    document.getElementById('delete-btn').style.display = '';
    showToast('Passport saved ✓');
  });
}

function deletePassport() {
  if (!confirm('Delete this passport?')) return;
  passports = passports.filter(p => p.id !== currentId);
  saveAll().then(() => showHome());
}

function buildPassportObj() {
  return {
    id: currentId,
    campaign: document.getElementById('f-campaign').value.trim(),
    date: document.getElementById('f-date').value,
    from: document.getElementById('f-from').value.trim(),
    to: document.getElementById('f-to').value.trim(),
    status: currentStatus,
    phase: currentPhase,
    done: document.getElementById('f-done').value.trim(),
    next: document.getElementById('f-next').value.trim(),
    intent: document.getElementById('f-intent').value.trim(),
    updatedAt: Date.now(),
  };
}

function clearForm() {
  ['f-campaign', 'f-from', 'f-to', 'f-done', 'f-next', 'f-intent'].forEach(id => {
    document.getElementById(id).value = '';
  });
}

/* ─────────────────────────────────────────
   STATUS
───────────────────────────────────────── */
function setStatus(color) {
  currentStatus = color;
  const banner = document.getElementById('status-banner');
  const label = document.getElementById('status-label');

  banner.className = 'status-banner' + (color ? ' s-' + color : '');
  label.textContent = color ? statusConfig[color].label : 'Set status';

  ['red', 'yellow', 'green'].forEach(c => {
    const pill = document.getElementById('pill-' + c);
    pill.className = 'pill' + (c === color ? ' ' + statusConfig[c].pill : '');
  });
}

/* ─────────────────────────────────────────
   PHASE
───────────────────────────────────────── */
function setPhase(idx) {
  currentPhase = idx;
  document.querySelectorAll('.phase-node').forEach((node, i) => {
    node.classList.remove('active', 'done');
    if (i < idx) node.classList.add('done');
    if (i === idx) node.classList.add('active');
  });
}

/* ─────────────────────────────────────────
   MRZ
───────────────────────────────────────── */
function updateMRZ() {
  const name = (document.getElementById('f-campaign').value || 'CAMPAIGN')
    .toUpperCase().replace(/[^A-Z0-9]/g, '<').substring(0, 16);
  const from = (document.getElementById('f-from').value || 'FROM')
    .toUpperCase().replace(/[^A-Z]/g, '<').substring(0, 8);
  const date = (document.getElementById('f-date').value || '').replace(/-/g, '').substring(2);
  const id = currentId ? currentId.replace('-', '') : 'HP00000';
  const line = (id + '<' + (date || '000000') + '<' + name + '<' + from + '<'.repeat(40)).substring(0, 44);
  document.getElementById('mrz-line').textContent = line;
}

/* ─────────────────────────────────────────
   COPY
───────────────────────────────────────── */
function copyPassport() {
  const p = buildPassportObj();
  const phase = phases[p.phase] || '—';
  const statusLabel = p.status ? statusConfig[p.status].label : 'not set';
  const lines = [
    `=== HANDOFF PASSPORT ${p.id || currentId} ===`,
    `Campaign: ${p.campaign || '—'}`,
    `Date: ${p.date || '—'}`,
    `From: ${p.from || '—'}`,
    `To: ${p.to || '—'}`,
    `Phase: ${phase}`,
    `Status: ${statusLabel}`,
    '',
    "01 — What's done?",
    p.done || '—',
    '',
    "02 — What's next?",
    p.next || '—',
    '',
    '03 — Strategic intent',
    p.intent || '—',
  ];
  navigator.clipboard.writeText(lines.join('\n')).then(() => showToast('Copied to clipboard ✓'));
}

/* ─────────────────────────────────────────
   TOAST
───────────────────────────────────────── */
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2000);
}

/* ─────────────────────────────────────────
   UTILS
───────────────────────────────────────── */
function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function escAttr(str) {
  return String(str).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  try {
    return new Date(dateStr + 'T00:00:00').toLocaleDateString('en-GB', {
      day: '2-digit', month: 'short', year: 'numeric'
    });
  } catch { return dateStr; }
}
