// Listens for paste messages from the popup and injects text into the active AI prompt box

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action !== 'paste') return;

  const text = msg.text;
  let injected = false;

  // ── ChatGPT ─────────────────────────────────────────────────────
  // ChatGPT uses a contenteditable div with id="prompt-textarea"
  const chatgptBox = document.querySelector('#prompt-textarea');
  if (chatgptBox) {
    chatgptBox.focus();
    // Insert at end of existing content
    const existing = chatgptBox.innerText.trim();
    const newContent = existing ? existing + '\n\n' + text : text;
    chatgptBox.innerText = newContent;
    // Move cursor to end
    const range = document.createRange();
    const sel = window.getSelection();
    range.selectNodeContents(chatgptBox);
    range.collapse(false);
    sel.removeAllRanges();
    sel.addRange(range);
    // Trigger React's synthetic event so ChatGPT enables the send button
    chatgptBox.dispatchEvent(new InputEvent('input', { bubbles: true }));
    injected = true;
  }

  // ── Gemini ──────────────────────────────────────────────────────
  // Gemini uses a rich text div with role="textbox"
  if (!injected) {
    const geminiBox = document.querySelector('rich-textarea .ql-editor') ||
                      document.querySelector('[contenteditable="true"][role="textbox"]') ||
                      document.querySelector('div.ql-editor');
    if (geminiBox) {
      geminiBox.focus();
      const existing = geminiBox.innerText.trim();
      const newContent = existing ? existing + '\n\n' + text : text;
      // Use execCommand for Gemini's Quill editor compatibility
      document.execCommand('selectAll', false, null);
      document.execCommand('insertText', false, newContent);
      geminiBox.dispatchEvent(new InputEvent('input', { bubbles: true }));
      injected = true;
    }
  }

  // ── Fallback: clipboard ─────────────────────────────────────────
  if (!injected) {
    navigator.clipboard.writeText(text).then(() => {
      sendResponse({ ok: false, reason: 'copied_to_clipboard' });
    });
    return true; // async
  }

  sendResponse({ ok: injected });
});
