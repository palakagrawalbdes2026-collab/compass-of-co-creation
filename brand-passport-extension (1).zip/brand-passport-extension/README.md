# Brand Passport — Chrome Extension

Store brand context templates and paste them into ChatGPT or Gemini with one click.

---

## Installation (takes ~60 seconds)

1. **Download** this folder and unzip it somewhere permanent (e.g. your Desktop or Documents)

2. **Open Chrome** and go to: `chrome://extensions`

3. **Enable Developer Mode** — toggle in the top-right corner

4. Click **"Load unpacked"** → select the `brand-passport-extension` folder

5. The ✦ icon appears in your toolbar. Pin it for easy access.

---

## How to use

1. Click the **✦ Brand Passport** icon in your Chrome toolbar
2. Fill in your brand's Voice, Values, Tone Do's and Don'ts
3. Hit **Save**
4. Open **ChatGPT** (chatgpt.com) or **Gemini** (gemini.google.com)
5. Click **✦ Paste into AI** — your brand context drops straight into the prompt box

You can create multiple brand templates using the **+** tab button.

---

## What gets pasted

```
--- BRAND CONTEXT ---
Brand: [Your brand name]

Brand Voice:
[your adjectives]

Brand Values:
[your values]

Tone Do's:
[your dos]

Tone Don'ts:
[your donts]
--- END BRAND CONTEXT ---
```

---

## Files

| File | Purpose |
|------|---------|
| `manifest.json` | Extension config |
| `popup.html` | The UI |
| `popup.js` | Template logic + Chrome storage |
| `content.js` | Injects text into ChatGPT/Gemini |
| `icons/` | Extension icons |
