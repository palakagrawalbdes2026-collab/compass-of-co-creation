const DEFAULT_TEMPLATES = [
  {
    id: 'tpl_1',
    name: 'Brand 1',
    voice: '',
    values: '',
    dos: '',
    donts: ''
  }
];

let templates = [];
let activeId = null;

// ── Storage helpers ──────────────────────────────────────────────
function load(cb) {
  chrome.storage.local.get('bp_templates', (res) => {
    templates = res.bp_templates || JSON.parse(JSON.stringify(DEFAULT_TEMPLATES));
    cb();
  });
}

function save(cb) {
  chrome.storage.local.set({ bp_templates: templates }, cb);
}

// ── Render ───────────────────────────────────────────────────────
function render() {
  const tabsEl = document.getElementById('tabs');
  const viewsEl = document.getElementById('views');

  // Clear existing tabs (keep the + button)
  Array.from(tabsEl.querySelectorAll('.tab')).forEach(t => t.remove());

  // Clear views
  viewsEl.innerHTML = '';

  if (templates.length === 0) {
    viewsEl.innerHTML = `
      <div class="empty-state">
        <div class="icon">✦</div>
        <p>No brand templates yet.<br>Hit <strong>+</strong> to create your first one.</p>
      </div>`;
    return;
  }

  templates.forEach((tpl) => {
    // Tab
    const tab = document.createElement('div');
    tab.className = 'tab' + (tpl.id === activeId ? ' active' : '');
    tab.textContent = tpl.name || 'Untitled';
    tab.title = tpl.name || 'Untitled';
    tab.dataset.id = tpl.id;
    tab.addEventListener('click', () => { activeId = tpl.id; render(); });
    tabsEl.insertBefore(tab, document.getElementById('btn-add-tab'));

    // View
    const view = document.createElement('div');
    view.className = 'view' + (tpl.id === activeId ? ' active' : '');
    view.dataset.id = tpl.id;
    view.innerHTML = `
      <div class="template-body">
        <div class="template-name-row">
          <input class="template-name-input" type="text" value="${esc(tpl.name)}" placeholder="Template name" data-field="name">
          <button class="btn-delete" title="Delete template" data-id="${tpl.id}">🗑</button>
        </div>

        <div class="field-row">
          <div class="field-label">Brand Voice</div>
          <div class="field-hint">3–5 adjectives (e.g. "warm, confident, playful, no-jargon")</div>
          <textarea rows="2" placeholder="warm, confident, direct…" data-field="voice">${esc(tpl.voice)}</textarea>
        </div>

        <div class="field-row">
          <div class="field-label">Brand Values</div>
          <div class="field-hint">2–3 core beliefs the brand stands for</div>
          <textarea rows="2" placeholder="Clarity over complexity, People before process…" data-field="values">${esc(tpl.values)}</textarea>
        </div>

        <div class="field-row">
          <div class="field-label">Tone Do's</div>
          <div class="field-hint">What works (e.g. "short sentences, active voice, emojis sometimes")</div>
          <textarea rows="2" placeholder="Short sentences, active voice, concrete examples…" data-field="dos">${esc(tpl.dos)}</textarea>
        </div>

        <div class="field-row">
          <div class="field-label">Tone Don'ts</div>
          <div class="field-hint">What to avoid (e.g. "no corporate speak, no puns")</div>
          <textarea rows="2" placeholder="No jargon, no exclamation marks, no passive voice…" data-field="donts">${esc(tpl.donts)}</textarea>
        </div>
      </div>

      <div class="action-bar">
        <button class="btn-save" data-id="${tpl.id}">Save</button>
        <button class="btn-paste" data-id="${tpl.id}">✦ Paste into AI</button>
      </div>
    `;

    // Name input → update tab label live
    view.querySelector('[data-field="name"]').addEventListener('input', (e) => {
      const t = getTemplate(tpl.id);
      if (t) t.name = e.target.value;
      const tabEl = tabsEl.querySelector(`.tab[data-id="${tpl.id}"]`);
      if (tabEl) { tabEl.textContent = e.target.value || 'Untitled'; tabEl.title = e.target.value || 'Untitled'; }
    });

    // Textarea inputs
    view.querySelectorAll('textarea').forEach(ta => {
      ta.addEventListener('input', (e) => {
        const t = getTemplate(tpl.id);
        if (t) t[e.target.dataset.field] = e.target.value;
      });
    });

    // Save button
    view.querySelector('.btn-save').addEventListener('click', () => {
      save(() => toast('Saved ✓'));
    });

    // Paste button
    view.querySelector('.btn-paste').addEventListener('click', () => {
      const t = getTemplate(tpl.id);
      if (!t) return;
      const text = buildPromptText(t);
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tab = tabs[0];
        if (!tab) return toast('No active tab found');
        const url = tab.url || '';
        const isChatGPT = url.includes('chatgpt.com') || url.includes('chat.openai.com');
        const isGemini = url.includes('gemini.google.com');
        if (!isChatGPT && !isGemini) {
          toast('Open ChatGPT or Gemini first');
          return;
        }
        chrome.tabs.sendMessage(tab.id, { action: 'paste', text }, (res) => {
          if (chrome.runtime.lastError) {
            // Content script may not be injected yet — inject manually
            chrome.scripting.executeScript({
              target: { tabId: tab.id },
              files: ['content.js']
            }, () => {
              setTimeout(() => {
                chrome.tabs.sendMessage(tab.id, { action: 'paste', text }, () => toast('Pasted ✓'));
              }, 400);
            });
          } else {
            toast('Pasted into prompt ✓');
          }
        });
      });
    });

    // Delete button
    view.querySelector('.btn-delete').addEventListener('click', () => {
      if (templates.length === 1) return toast('Need at least one template');
      templates = templates.filter(t => t.id !== tpl.id);
      activeId = templates[0]?.id || null;
      save(() => render());
    });

    viewsEl.appendChild(view);
  });
}

// ── Helpers ──────────────────────────────────────────────────────
function getTemplate(id) { return templates.find(t => t.id === id); }

function esc(str) {
  return (str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function buildPromptText(t) {
  const lines = ['--- BRAND CONTEXT ---'];
  if (t.name)   lines.push(`Brand: ${t.name}`);
  if (t.voice)  lines.push(`\nBrand Voice:\n${t.voice}`);
  if (t.values) lines.push(`\nBrand Values:\n${t.values}`);
  if (t.dos)    lines.push(`\nTone Do's:\n${t.dos}`);
  if (t.donts)  lines.push(`\nTone Don'ts:\n${t.donts}`);
  lines.push('--- END BRAND CONTEXT ---\n');
  return lines.join('\n');
}

function uid() { return 'tpl_' + Date.now(); }

function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 2000);
}

// ── Init ─────────────────────────────────────────────────────────
load(() => {
  if (!activeId && templates.length > 0) activeId = templates[0].id;
  render();
});

document.getElementById('btn-add-tab').addEventListener('click', () => {
  const newTpl = { id: uid(), name: `Brand ${templates.length + 1}`, voice: '', values: '', dos: '', donts: '' };
  templates.push(newTpl);
  activeId = newTpl.id;
  render();
});
