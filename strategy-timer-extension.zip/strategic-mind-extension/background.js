// Strategic Mind – Background Service Worker

const AI_DOMAINS = [
  "chat.openai.com", "chatgpt.com",
  "claude.ai", "anthropic.com",
  "gemini.google.com", "bard.google.com",
  "copilot.microsoft.com", "bing.com/chat",
  "perplexity.ai",
  "character.ai",
  "poe.com",
  "huggingface.co",
  "cohere.com",
  "mistral.ai",
  "you.com",
  "phind.com",
  "writesonic.com",
  "jasper.ai",
  "copy.ai",
  "notion.so/ai",
  "labs.perplexity.ai"
];

function isAIDomain(url) {
  try {
    const hostname = new URL(url).hostname.replace("www.", "");
    return AI_DOMAINS.some(d => hostname === d || hostname.endsWith("." + d));
  } catch {
    return false;
  }
}

// On install, set defaults
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    sessionActive: false,
    sessionStartTime: null,
    sessionDuration: 30, // minutes
    timerInterval: 30,   // recurring every N minutes
    autoRecurring: true,
    nextSessionTime: null,
    totalSessions: 0,
    stickyNote: "Strategic decision? Close all AI tabs.",
    customAIDomains: []
  });
});

// Listen for messages from popup / content
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "START_SESSION") {
    startSession(msg.duration);
    sendResponse({ ok: true });
  }
  if (msg.type === "STOP_SESSION") {
    stopSession();
    sendResponse({ ok: true });
  }
  if (msg.type === "GET_STATE") {
    chrome.storage.local.get(null, (data) => sendResponse(data));
    return true;
  }
  if (msg.type === "CLOSE_AI_TABS") {
    closeAITabs().then(count => sendResponse({ count }));
    return true;
  }
  if (msg.type === "UPDATE_STICKY") {
    chrome.storage.local.set({ stickyNote: msg.text });
    sendResponse({ ok: true });
  }
  if (msg.type === "SESSION_ENDED_ACK") {
    chrome.storage.local.get(["autoRecurring", "timerInterval", "totalSessions"], (data) => {
      const newTotal = (data.totalSessions || 0) + 1;
      chrome.storage.local.set({ totalSessions: newTotal });
      if (data.autoRecurring) {
        const nextTime = Date.now() + data.timerInterval * 60 * 1000;
        chrome.storage.local.set({ nextSessionTime: nextTime });
        chrome.alarms.create("nextSession", { when: nextTime });
      }
    });
    sendResponse({ ok: true });
  }
  return true;
});

async function closeAITabs() {
  const tabs = await chrome.tabs.query({});
  const aiTabs = tabs.filter(t => t.url && isAIDomain(t.url));
  await Promise.all(aiTabs.map(t => chrome.tabs.remove(t.id)));
  return aiTabs.length;
}

async function startSession(durationMinutes) {
  const now = Date.now();
  await chrome.storage.local.set({
    sessionActive: true,
    sessionStartTime: now,
    sessionDuration: durationMinutes
  });

  // Close all AI tabs
  await closeAITabs();

  // Set alarm for session end
  chrome.alarms.create("sessionEnd", { when: now + durationMinutes * 60 * 1000 });

  // Notify all existing tabs to show overlay
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: showOverlayInTab
      });
    } catch (e) { /* skip restricted tabs */ }
  }
}

async function stopSession() {
  await chrome.storage.local.set({
    sessionActive: false,
    sessionStartTime: null
  });
  chrome.alarms.clear("sessionEnd");

  // Remove overlay from all tabs
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: removeOverlayInTab
      });
    } catch (e) { /* skip */ }
  }
}

function showOverlayInTab() {
  window.postMessage({ type: "STRATEGIC_MIND_SHOW_OVERLAY" }, "*");
}

function removeOverlayInTab() {
  window.postMessage({ type: "STRATEGIC_MIND_HIDE_OVERLAY" }, "*");
}

// Handle alarms
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === "sessionEnd") {
    await chrome.storage.local.set({ sessionActive: false, sessionStartTime: null });
    // Signal all tabs that session ended
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: signalSessionEndInTab
        });
      } catch (e) { /* skip */ }
    }
  }
  if (alarm.name === "nextSession") {
    chrome.storage.local.get(["sessionDuration", "autoRecurring"], (data) => {
      if (data.autoRecurring) startSession(data.sessionDuration || 30);
    });
  }
});

function signalSessionEndInTab() {
  window.postMessage({ type: "STRATEGIC_MIND_SESSION_END" }, "*");
}

// When a new tab opens during an active session, inject overlay
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;

  // Block AI domains during session
  chrome.storage.local.get(["sessionActive", "customAIDomains"], async (data) => {
    if (data.sessionActive && tab.url && isAIDomain(tab.url)) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId },
          func: blockAIPage
        });
      } catch (e) { /* skip */ }
    }

    if (data.sessionActive) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId },
          func: showOverlayInTab
        });
      } catch (e) { /* skip */ }
    }
  });
});

function blockAIPage() {
  window.postMessage({ type: "STRATEGIC_MIND_BLOCK_AI" }, "*");
}
