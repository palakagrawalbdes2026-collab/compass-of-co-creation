// Strategic Mind – Content Script
// Listens for messages from background and manages the screen overlay

(function () {
  'use strict';

  let overlayEl = null;
  let timerInterval = null;
  let endTime = null;

  // Listen for postMessage from background scripts
  window.addEventListener("message", (e) => {
    if (!e.data || typeof e.data.type !== "string") return;
    switch (e.data.type) {
      case "STRATEGIC_MIND_SHOW_OVERLAY":
        chrome.storage.local.get(["sessionStartTime", "sessionDuration"], (data) => {
          if (data.sessionStartTime && data.sessionDuration) {
            endTime = data.sessionStartTime + data.sessionDuration * 60 * 1000;
            showOverlay();
          }
        });
        break;
      case "STRATEGIC_MIND_HIDE_OVERLAY":
        removeOverlay();
        break;
      case "STRATEGIC_MIND_SESSION_END":
        showEndScreen();
        break;
      case "STRATEGIC_MIND_BLOCK_AI":
        showBlockedPage();
        break;
    }
  });

  // Also check on load if session is active
  chrome.storage.local.get(["sessionActive", "sessionStartTime", "sessionDuration"], (data) => {
    if (data.sessionActive && data.sessionStartTime) {
      endTime = data.sessionStartTime + data.sessionDuration * 60 * 1000;
      if (Date.now() < endTime) {
        showOverlay();
      }
    }
  });

  function showOverlay() {
    if (overlayEl) return; // already showing

    overlayEl = document.createElement("div");
    overlayEl.id = "strategic-mind-overlay";
    overlayEl.innerHTML = getOverlayHTML();
    document.documentElement.appendChild(overlayEl);

    // Inject styles
    const style = document.createElement("style");
    style.id = "strategic-mind-styles";
    style.textContent = getStyles();
    document.head.appendChild(style);

    startCountdown();

    // Prevent scroll behind overlay
    document.documentElement.style.overflow = "hidden";
  }

  function removeOverlay() {
    if (overlayEl) {
      overlayEl.remove();
      overlayEl = null;
    }
    const style = document.getElementById("strategic-mind-styles");
    if (style) style.remove();
    if (timerInterval) clearInterval(timerInterval);
    document.documentElement.style.overflow = "";
  }

  function showEndScreen() {
    if (overlayEl) {
      const content = overlayEl.querySelector(".sm-content");
      if (content) {
        content.innerHTML = getEndHTML();
      }
      clearInterval(timerInterval);

      // Auto dismiss after 8s
      setTimeout(() => {
        removeOverlay();
        chrome.runtime.sendMessage({ type: "SESSION_ENDED_ACK" });
      }, 8000);
    }
  }

  function showBlockedPage() {
    document.documentElement.innerHTML = getBlockedPageHTML();
  }

  function startCountdown() {
    updateTimer();
    timerInterval = setInterval(() => {
      if (!overlayEl) { clearInterval(timerInterval); return; }
      const remaining = endTime - Date.now();
      if (remaining <= 0) {
        showEndScreen();
        clearInterval(timerInterval);
        return;
      }
      updateTimer();
    }, 1000);
  }

  function updateTimer() {
    const el = document.getElementById("sm-countdown");
    if (!el) return;
    const remaining = Math.max(0, endTime - Date.now());
    const mins = Math.floor(remaining / 60000);
    const secs = Math.floor((remaining % 60000) / 1000);
    el.textContent = `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;

    // Update ring
    const ring = document.getElementById("sm-ring");
    if (ring) {
      chrome.storage.local.get(["sessionDuration"], (data) => {
        const total = (data.sessionDuration || 30) * 60 * 1000;
        const progress = 1 - (remaining / total);
        const circumference = 2 * Math.PI * 54;
        ring.style.strokeDashoffset = circumference * (1 - progress);
      });
    }
  }

  function getOverlayHTML() {
    return `
      <div class="sm-backdrop"></div>
      <div class="sm-content">
        <div class="sm-header">
          <div class="sm-logo">◈</div>
          <div class="sm-label">STRATEGIC THINKING TIME</div>
        </div>
        <div class="sm-timer-wrap">
          <svg class="sm-ring-svg" viewBox="0 0 120 120">
            <circle class="sm-ring-bg" cx="60" cy="60" r="54"/>
            <circle class="sm-ring-progress" id="sm-ring" cx="60" cy="60" r="54"
              stroke-dasharray="${2 * Math.PI * 54}"
              stroke-dashoffset="${2 * Math.PI * 54}"/>
          </svg>
          <div class="sm-countdown-wrap">
            <div id="sm-countdown" class="sm-countdown">30:00</div>
            <div class="sm-countdown-label">remaining</div>
          </div>
        </div>
        <div class="sm-divider"></div>
        <div class="sm-message">No AI. No screens.</div>
        <div class="sm-submessage">Use whiteboards &amp; sticky notes.<br>Strategic framing happens here — in your mind.</div>
        <div class="sm-tools">
          <div class="sm-tool">📋 Sticky Notes</div>
          <div class="sm-tool">📐 Whiteboard</div>
          <div class="sm-tool">🧠 Deep Thinking</div>
          <div class="sm-tool">✍️ Pen &amp; Paper</div>
        </div>
        <button class="sm-end-btn" id="sm-end-btn">End Session Early</button>
      </div>
    `;
  }

  function getEndHTML() {
    return `
      <div class="sm-header">
        <div class="sm-logo">✦</div>
        <div class="sm-label">SESSION COMPLETE</div>
      </div>
      <div class="sm-end-icon">🎯</div>
      <div class="sm-message">Strategic Thinking Done.</div>
      <div class="sm-submessage">Great work. Your decisions are now sharper.<br>Returning to your workspace in a moment...</div>
      <div class="sm-progress-bar"><div class="sm-progress-fill"></div></div>
    `;
  }

  function getBlockedPageHTML() {
    return `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>AI Blocked – Strategic Mind</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    background: #0a0a0a;
    color: #f0ede4;
    font-family: 'Georgia', serif;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    text-align: center;
  }
  .wrap { max-width: 480px; padding: 48px; }
  .icon { font-size: 64px; margin-bottom: 32px; }
  h1 { font-size: 28px; font-weight: 400; letter-spacing: 0.08em; margin-bottom: 16px; color: #e8c97a; }
  p { font-size: 15px; line-height: 1.8; color: #a09d94; margin-bottom: 32px; }
  .badge { display: inline-block; padding: 8px 20px; border: 1px solid #e8c97a44; border-radius: 2px; font-size: 12px; letter-spacing: 0.15em; color: #e8c97a; }
</style>
</head>
<body>
<div class="wrap">
  <div class="icon">🚫</div>
  <h1>AI Access Blocked</h1>
  <p>A Strategic Thinking session is active.<br>Step away from the screen.<br>Whiteboard. Sticky notes. Human minds only.</p>
  <div class="badge">STRATEGIC MIND — ACTIVE SESSION</div>
</div>
</body>
</html>`;
  }

  function getStyles() {
    return `
      #strategic-mind-overlay {
        position: fixed !important;
        inset: 0 !important;
        z-index: 2147483647 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        font-family: 'Georgia', 'Times New Roman', serif !important;
      }
      #strategic-mind-overlay .sm-backdrop {
        position: absolute;
        inset: 0;
        background: #0a1525;
        background-image:
          radial-gradient(ellipse 80% 60% at 50% 50%, #132240 0%, #080f1e 70%);
      }
      #strategic-mind-overlay .sm-content {
        position: relative;
        z-index: 1;
        text-align: center;
        color: #dce8f4;
        max-width: 520px;
        padding: 48px 40px;
        border: 1px solid #1e3050;
        background: rgba(10, 21, 37, 0.88);
        backdrop-filter: blur(20px);
        box-shadow: 0 0 80px rgba(232, 213, 160, 0.06), inset 0 0 40px rgba(30, 60, 100, 0.15);
        font-family: 'Inter', 'Helvetica Neue', sans-serif;
      }
      #strategic-mind-overlay .sm-header {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 12px;
        margin-bottom: 36px;
      }
      #strategic-mind-overlay .sm-logo {
        font-size: 22px;
        color: #e8c97a;
        line-height: 1;
      }
      #strategic-mind-overlay .sm-label {
        font-size: 11px;
        letter-spacing: 0.25em;
        color: #e8c97a;
        font-family: 'Courier New', monospace;
        font-weight: 400;
      }
      #strategic-mind-overlay .sm-timer-wrap {
        position: relative;
        width: 160px;
        height: 160px;
        margin: 0 auto 32px;
      }
      #strategic-mind-overlay .sm-ring-svg {
        width: 160px;
        height: 160px;
        transform: rotate(-90deg);
      }
      #strategic-mind-overlay .sm-ring-bg {
        fill: none;
        stroke: #1a2e48;
        stroke-width: 3;
      }
      #strategic-mind-overlay .sm-ring-progress {
        fill: none;
        stroke: #e8d5a0;
        stroke-width: 3;
        stroke-linecap: round;
        transition: stroke-dashoffset 1s linear;
      }
      #strategic-mind-overlay .sm-countdown-wrap {
        position: absolute;
        inset: 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
      }
      #strategic-mind-overlay .sm-countdown {
        font-size: 42px;
        font-weight: 300;
        color: #dce8f4;
        letter-spacing: 0.04em;
        line-height: 1;
        font-variant-numeric: tabular-nums;
        font-family: 'Inter', 'Helvetica Neue', sans-serif;
      }
      #strategic-mind-overlay .sm-countdown-label {
        font-size: 10px;
        letter-spacing: 0.2em;
        color: #3a5a7a;
        margin-top: 6px;
        font-family: 'Inter', 'Helvetica Neue', sans-serif;
        text-transform: uppercase;
      }
      #strategic-mind-overlay .sm-divider {
        width: 40px;
        height: 1px;
        background: rgba(232, 213, 160, 0.3);
        margin: 0 auto 24px;
      }
      #strategic-mind-overlay .sm-message {
        font-size: 22px;
        font-weight: 400;
        color: #dce8f4;
        letter-spacing: 0.04em;
        margin-bottom: 12px;
        font-family: 'Georgia', serif;
      }
      #strategic-mind-overlay .sm-submessage {
        font-size: 13px;
        line-height: 1.9;
        color: #4a6a8a;
        margin-bottom: 28px;
        font-style: italic;
      }
      #strategic-mind-overlay .sm-tools {
        display: flex;
        gap: 10px;
        justify-content: center;
        flex-wrap: wrap;
        margin-bottom: 32px;
      }
      #strategic-mind-overlay .sm-tool {
        padding: 7px 14px;
        border: 1px solid #1e3050;
        font-size: 11px;
        color: #6a8aaa;
        letter-spacing: 0.05em;
        font-family: 'Inter', 'Helvetica Neue', sans-serif;
      }
      #strategic-mind-overlay .sm-end-btn {
        background: transparent;
        border: 1px solid #1e3050;
        color: #2e4a6a;
        font-size: 10px;
        letter-spacing: 0.18em;
        padding: 10px 24px;
        cursor: pointer;
        font-family: 'Inter', 'Helvetica Neue', sans-serif;
        text-transform: uppercase;
        transition: all 0.2s;
      }
      #strategic-mind-overlay .sm-end-btn:hover {
        border-color: #3a5a7a;
        color: #6a9aba;
      }
      #strategic-mind-overlay .sm-end-icon {
        font-size: 48px;
        margin-bottom: 20px;
      }
      #strategic-mind-overlay .sm-progress-bar {
        width: 100%;
        height: 2px;
        background: #1e1a12;
        margin-top: 32px;
        overflow: hidden;
      }
      #strategic-mind-overlay .sm-progress-fill {
        height: 100%;
        background: #e8d5a0;
        width: 0%;
        animation: sm-progress 8s linear forwards;
      }
      @keyframes sm-progress {
        to { width: 100%; }
      }
    `;
  }

  // Delegate click for end session button
  document.addEventListener("click", (e) => {
    if (e.target && e.target.id === "sm-end-btn") {
      chrome.runtime.sendMessage({ type: "STOP_SESSION" });
      removeOverlay();
    }
  }, true);

})();
