// Strategic Mind – Popup Script

let state = {};
let countdownInterval = null;
let nextInterval = null;
let selectedDuration = 30;

const $ = id => document.getElementById(id);

async function loadState() {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ type: "GET_STATE" }, resolve);
  });
}

function showToast(msg) {
  const t = $("toast");
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2200);
}

function updateUI(data) {
  state = data;

  // Status dot
  const dot = $("status-dot");
  const statusText = $("status-text");
  if (data.sessionActive) {
    dot.classList.add("active");
    statusText.textContent = "Active";
    statusText.style.color = "#4a8a50";
  } else {
    dot.classList.remove("active");
    statusText.textContent = "Idle";
    statusText.style.color = "";
  }

  // Sticky note
  $("sticky-text").value = data.stickyNote || "Strategic decision? Close all AI tabs.";

  // Duration selector
  selectedDuration = data.sessionDuration || 30;
  document.querySelectorAll(".dur-btn").forEach(btn => {
    btn.classList.toggle("active", parseInt(btn.dataset.min) === selectedDuration);
  });

  // Session panel
  const panel = $("session-panel");
  const stopRow = $("stop-row");
  const startBtn = $("btn-start");
  const durSel = $("dur-selector");

  if (data.sessionActive) {
    panel.classList.add("visible");
    stopRow.style.display = "flex";
    startBtn.style.display = "none";
    durSel.style.opacity = "0.3";
    durSel.style.pointerEvents = "none";
    startCountdownUI(data);
  } else {
    panel.classList.remove("visible");
    stopRow.style.display = "none";
    startBtn.style.display = "flex";
    durSel.style.opacity = "";
    durSel.style.pointerEvents = "";
    clearInterval(countdownInterval);
  }

  // Auto-recurring toggle
  const track = $("toggle-track");
  if (data.autoRecurring) {
    track.classList.add("on");
  } else {
    track.classList.remove("on");
  }

  // Stats
  $("stat-sessions").textContent = data.totalSessions || 0;
  $("stat-minutes").textContent = ((data.totalSessions || 0) * (data.sessionDuration || 30));
  $("stat-interval").textContent = (data.timerInterval || 30) + "m";

  // Next session
  updateNextSession(data);
}

function startCountdownUI(data) {
  clearInterval(countdownInterval);
  const endTime = data.sessionStartTime + data.sessionDuration * 60 * 1000;
  const total = data.sessionDuration * 60 * 1000;

  function tick() {
    const remaining = Math.max(0, endTime - Date.now());
    const mins = Math.floor(remaining / 60000);
    const secs = Math.floor((remaining % 60000) / 1000);
    $("session-countdown").textContent =
      `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;

    const progress = ((total - remaining) / total) * 100;
    $("progress-fill").style.width = progress + "%";

    if (remaining <= 0) {
      clearInterval(countdownInterval);
      $("session-countdown").textContent = "00:00";
    }
  }
  tick();
  countdownInterval = setInterval(tick, 1000);
}

function updateNextSession(data) {
  const el = $("next-session");
  const timeEl = $("next-time");
  clearInterval(nextInterval);

  if (!data.sessionActive && data.autoRecurring && data.nextSessionTime && data.nextSessionTime > Date.now()) {
    el.classList.add("visible");
    function tick() {
      const remaining = Math.max(0, data.nextSessionTime - Date.now());
      if (remaining <= 0) {
        el.classList.remove("visible");
        clearInterval(nextInterval);
        return;
      }
      const mins = Math.floor(remaining / 60000);
      const secs = Math.floor((remaining % 60000) / 1000);
      timeEl.textContent = `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
    }
    tick();
    nextInterval = setInterval(tick, 1000);
  } else {
    el.classList.remove("visible");
  }
}

// ── Event Listeners ──

// Duration buttons
document.querySelectorAll(".dur-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    selectedDuration = parseInt(btn.dataset.min);
    document.querySelectorAll(".dur-btn").forEach(b => b.classList.toggle("active", b === btn));
    chrome.storage.local.set({ sessionDuration: selectedDuration, timerInterval: selectedDuration });
    $("stat-interval").textContent = selectedDuration + "m";
  });
});

// Start session
$("btn-start").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "START_SESSION", duration: selectedDuration }, () => {
    showToast("Session started – AI tabs closed.");
    setTimeout(async () => {
      const data = await loadState();
      updateUI(data);
    }, 300);
  });
});

// Stop session
$("btn-stop").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "STOP_SESSION" }, () => {
    showToast("Session ended.");
    setTimeout(async () => {
      const data = await loadState();
      updateUI(data);
    }, 300);
  });
});

// Close AI tabs
$("btn-close-ai").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "CLOSE_AI_TABS" }, (res) => {
    if (res && res.count > 0) {
      showToast(`Closed ${res.count} AI tab${res.count > 1 ? "s" : ""}.`);
    } else {
      showToast("No AI tabs found.");
    }
  });
});

// Toggle auto-recurring
$("toggle-recurring").addEventListener("click", () => {
  const newVal = !state.autoRecurring;
  chrome.storage.local.set({ autoRecurring: newVal }, async () => {
    const data = await loadState();
    updateUI(data);
    showToast(newVal ? "Auto-recurring on." : "Auto-recurring off.");
  });
});

// Sticky note
let stickyTimeout;
$("sticky-text").addEventListener("input", () => {
  clearTimeout(stickyTimeout);
  stickyTimeout = setTimeout(() => {
    chrome.runtime.sendMessage({ type: "UPDATE_STICKY", text: $("sticky-text").value });
  }, 600);
});

// ── Init ──
loadState().then(updateUI);
